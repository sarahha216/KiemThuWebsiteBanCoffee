﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sample
{
    public class Input
    {
        public int Row { get; set; } = 1;
        public int Column { get; set; } = 4;
        public int N { get; set; } = 2;
    }
}
