﻿using Bytescout.Spreadsheet;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Linq;
using System.Threading;

namespace sample
{
    [TestClass]
    public class UnitDangNhap
    {
        IWebDriver webDriver;
        const int waitingTime = 1000;

        Input obj = new Input();
        Account account = new Account();
        
        [TestMethod]
        public void ReadExcel()
        {
            Spreadsheet doc = new Spreadsheet();
            doc.LoadFromFile(@"C:\Users\AD\Downloads\sample.xlsx");
            Worksheet worksheet = doc.Workbook.Worksheets.ByName("Sheet1");

            //cột 5,6,7
            int DEA = obj.Column + 3;
            int colData = obj.Column;
            int colExpected = obj.Column + 1;
            int colActual = obj.Column + 2;

            for (int i = obj.Row; i < obj.N; i++)
            {
                account.DataTest = worksheet.Cell(i, colData).ToString();
                var t = account.DataTest.Split('\n');
                account.UserName = t[0];
                account.Password = t[1];
                DangNhap();
                account.Expected = worksheet.Cell(i, colExpected).ToString();

                webDriver.Quit();
                Assert.AreEqual(account.Expected, account.Actual);
            }
            doc.Close();
        }
        public void DangNhap()
        {
            By taiKhoan = By.Name("SDT");
            By matKhau = By.Name("MATKHAU");
            By loginButton = By.Name("BtnSubmit");

            webDriver = new ChromeDriver();
            Thread.Sleep(waitingTime);
            webDriver.Navigate().GoToUrl("http://coffeeshop.somee.com/Authentication/Login");
            Thread.Sleep(waitingTime);
            webDriver.Manage().Window.Maximize();

            //đăng nhập
            webDriver.FindElement(taiKhoan).SendKeys(account.UserName);
            Thread.Sleep(waitingTime);
            webDriver.FindElement(matKhau).SendKeys(account.Password);
            Thread.Sleep(waitingTime);

            var btnLogin = webDriver.FindElement(loginButton);
            btnLogin.Click();
            Thread.Sleep(waitingTime);

            account.Actual = webDriver.FindElement(By.XPath("/html/body/div[1]/div/ul/a[1]")).Text;
            Console.WriteLine(account.Actual);
        }
    }
}
